@extends('layouts.master')

@section('content')
	<div class="row">
        <div class="col-md-12">
            <p class="quote">The beautiful Laravel</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos recusandae amet, placeat sed provident eos nisi cum. Illo nam, ea non veritatis, est, id suscipit ab aliquam alias corrupti incidunt!</p>
    		<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio sequi non fuga perspiciatis, atque rem quaerat, assumenda ad laboriosam inventore quibusdam ducimus eveniet nihil illum recusandae, hic fugiat dignissimos optio.</p>
        </div>
    </div>
@endsection